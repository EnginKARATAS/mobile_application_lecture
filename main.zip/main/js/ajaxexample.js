$(document).ready(function () {

  $("#btn").click(function () {
    alert("Hello");
    alert(123);
  });

});
